package com.adp.wfnddt.tests;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;
import java.io.IOException;
import java.net.UnknownHostException;
import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.adp.wfnddt.core.BrowserManager;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.DDTController.BrowserType;

/**************************
 * JUnit Test Fixture
 * @author autoxpert
 *
 */

@RunWith(Cucumber.class)	// JUnit uses this class to run this test fixture.
@CucumberOptions(
		features={"src/main/resources/Features"},
		tags = {"@ShoeStoreTest"},
		glue = {"com.adp.wfnddt.cukeextensions"}
)
public class CukesRunner_ShoeStore {
	@BeforeClass
	public static void startup() throws UnknownHostException, DatatypeConfigurationException, DDTFrameworkException {
		System.out.println("In startup()...");

		// Set Java system properties
		String tempDir = null;

		switch(DDTController.getOS()) {
    	case Windows:
    		tempDir = "C:/Temp";
    		break;
    	case MacOSX:
    	case Linux:
    		tempDir = DDTController.getUserHome() + "/temp";
    		break;
    	default:
    		throw new DDTFrameworkException(CukesRunner_ShoeStore.class, "DDT execution is not supported on this OS.");
    	}

		//Set Selenium Grid
		//DDTController.setSeleniumGridURL("http://cdlautowfnrpt:4444/wd/hub");

		DDTController.setSysProperty("report.path", tempDir);


		// Set DDT argument values.
		DDTController.setRunName("DDT_Run_Local");
		DDTController.setBrowserType(BrowserType.Chrome64);

		// Initialize reporting.
		DDTController.createResultsReporter();
		DDTController.getResultsReporter().startRun(DDTController.getRunID(), DDTController.getRunName());
		return;
	}

	@AfterClass
	public static void tearDown() throws JAXBException, DatatypeConfigurationException, IOException{
		System.out.println("In tearDown...");
		DDTController.getResultsReporter().endRun();
		DDTController.getResultsReporter().generateHTMLReport();

		BrowserManager.closeBrowser();
		return;
	}

}
