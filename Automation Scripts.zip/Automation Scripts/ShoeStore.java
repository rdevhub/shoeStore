package com.adp.wfnddt.components.shoestore;


import java.io.IOException;
import javax.xml.datatype.DatatypeConfigurationException;

import org.openqa.selenium.WebDriver;

import com.adp.wfnddt.aspects.Component;
import com.adp.wfnddt.commonmethods.*;
import com.adp.wfnddt.core.BrowserManager;
import com.adp.wfnddt.core.DDTComponentBase;
import com.adp.wfnddt.core.DDTController;
import com.adp.wfnddt.core.DDTFrameworkException;
import com.adp.wfnddt.core.GlobalVariables;
import com.adp.wfnddt.objectmanager.ObjectTypes;
import com.adp.wfnddt.objectmanager.WebObject;
import com.adp.wfnddt.parammanager.ParamManager;
import com.adp.wfnddt.results.DDTResultsReporter;
import com.adp.wfnddt.results.jaxb.StatusType;

public class ShoeStore extends DDTComponentBase {
	private static final String OR_Path = "/Objects/ShoeStore/ShoeStore.json";
	private WebDriver m_webDriver = null; 
	DDTResultsReporter results = DDTController.getResultsReporter();
	
	
	public ShoeStore() throws DDTFrameworkException {
		loadObjectRepository(OR_Path);
		return;
	}
	
	
	
	@Component(Name = "Open - Shoe Store Site", Params = {})
	public void openOpenShoeStoreSite(ParamManager pm)
			throws DDTFrameworkException, IOException, DatatypeConfigurationException, InterruptedException {
		
		
			GlobalVariables.setRuntimeURL("https://rb-shoe-store.herokuapp.com");
			
			m_webDriver = BrowserManager.setupWebDriver();
		
			m_webDriver.get(GlobalVariables.getRuntimeURL());
			
			General.sleep(10);
			BrowserManager.maximizeWindow();
		
	}
	
	@Component(Name = "Verify Fields on Shoe Store Page", Params = {
			"Welcome|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"Home|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"January|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"February|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"December|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"Remind Me New Shoes Submit|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"Promotional Code Submit|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"Select Brand|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			"Search Brand|*^*|Valid Values: [EXISTS], [DOES NOT EXIST]",
			})
	public void verifyActionOptionOnChangeStatusPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		

		try {
			ObjectTypes Page = Browser.Page("Shoe Store");
			results.startVerificationLogStep();
			Page.WebObject("Welcome").verifyObjectProperties(pm.Parameter("Welcome"));
			Page.WebButton("Home").verifyObjectProperties(pm.Parameter("Home"));
			Page.WebButton("January").verifyObjectProperties(pm.Parameter("January"));
			Page.WebButton("February").verifyObjectProperties(pm.Parameter("February"));
			Page.WebButton("December").verifyObjectProperties(pm.Parameter("December"));
			Page.WebButton("Remind Me New Shoes Submit").verifyObjectProperties(pm.Parameter("Remind Me New Shoes Submit"));
			Page.WebButton("Promotional Code Submit").verifyObjectProperties(pm.Parameter("Promotional Code Submit"));
			Page.WebComboBox("Select Brand").verifyObjectProperties(pm.Parameter("Select Brand"));
			Page.WebButton("Search Brand").verifyObjectProperties(pm.Parameter("Search Brand"));
			
		} catch (Exception e) {
			results.endVerificationLogStep(StatusType.FAILED);			
		} finally {
			results.endVerificationLogStep();
		}
	}
	
	@Component(Name = "Verify On Screen Message on Shoe Store Page", Params = { "Expected_Message" })
	public void VerifyOnScreenMessageOnShoeStorePage(ParamManager pm)
			throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		results.startVerificationLogStep();
		new WebObject("XPATH://*[text()='" + pm.Parameter("Expected_Message") + "']").verifyObjectProperties("[EXISTS]");
		results.endVerificationLogStep();
		
	}
	
	
	@Component(Name = "Enter Data on Remind Me of New Shoes", Params = {
			"Email Address|*^*|Valid Values: Email Address"
			})
	public void enterDataonRemindMeofNewShoes(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		ObjectTypes Page = Browser.Page("Shoe Store");
		Page.WebTextBox("Remind Me New Shoes Email").set(pm.Parameter("Email Address"));
		Page.WebButton("Remind Me New Shoes Submit").actionClick();
		
	}
	
	@Component(Name = "Enter Data on Promotional Code", Params = {
			"Promotional Code|*^*|Valid Values: valid promo code"
			})
	public void enterDataonPromotionalCode(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		ObjectTypes Page = Browser.Page("Shoe Store");
		Page.WebTextBox("Promotional Code").set(pm.Parameter("Promotional Code"));
		Page.WebButton("Promotional Code Submit").actionClick();
		
	}
	
	@Component(Name = "Click on Shoe Store Home Page", Params = {
			"Button_To_Click|*^*|Valid Values: Home,January,February,March,April,May,June,July,August,September,October,November,December,All Shoes,Back"
			})
	public void clickonShoeStoreHomePage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		ObjectTypes Page = Browser.Page("Shoe Store");
		Page.WebButton("Home").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("January").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("February").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("March").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("April").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("May").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("June").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("July").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("August").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("September").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("October").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("November").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("December").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("All Shoes").click(pm.Parameter("Button_To_Click"));
		Page.WebButton("Back").click(pm.Parameter("Button_To_Click"));
		General.sleep(2);
	}
	
	@Component(Name = "Enter Data on Choose a Brand", Params = {
			"Select Brand|*^*|Valid Values: valid Shoe brand. Ex: Alegria"
			})
	public void enterDataonChooseaBrand(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		ObjectTypes Page = Browser.Page("Shoe Store");
		Page.WebComboBox("Select Brand").select(pm.Parameter("Select Brand"));
		Page.WebButton("Search Brand").actionClick();
		
	}
	
	@Component(Name = "Verify Data on Shoe List Page", Params = { "Shoe_Brand_OR_Month|*^*|Valid Values:January, Valentino" })
	public void verifyDataonShoeListPage(ParamManager pm)
			throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		ObjectTypes Page = Browser.Page("Shoe Store");
		results.startVerificationLogStep();
		new WebObject("XPATH://h2[text()=\"" + pm.Parameter("Shoe_Brand_OR_Month") + "'s Shoes\"]").verifyObjectProperties("[EXISTS]");
		Page.WebObject("Shoe Results").verifyObjectProperties("[EXISTS]");
		results.endVerificationLogStep();
	}
	
	@Component(Name = "Verify Shoe Details on Shoe List Page", Params = { "Brand|*^*|Ex: Valentino","Name","Price","Description","Release Month" })
	public void verifyShoeDetailsonShoeListPage(ParamManager pm)
			throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		String shoeNameObject = "XPATH:(//tr[@class='shoe_result_row']//td[@class='shoe_result_value shoe_name' and contains(text(),'" + pm.Parameter("Name") + "')])[1]";
		
		results.startVerificationLogStep();
		new WebObject(shoeNameObject).verifyObjectProperties("[EXISTS]");
		new WebObject(shoeNameObject + "/parent::tr/preceding-sibling::tr//td[@class='shoe_result_value shoe_brand']").verifyValue(pm.Parameter("Brand"));
		new WebObject(shoeNameObject + "/parent::tr/following-sibling::tr//td[@class='shoe_result_value shoe_price']").verifyValue(pm.Parameter("Price"));
		new WebObject(shoeNameObject + "/parent::tr/following-sibling::tr//td[@class='shoe_result_value shoe_description']").verifyValue(pm.Parameter("Description"));
		new WebObject(shoeNameObject + "/parent::tr/following-sibling::tr//td[@class='shoe_result_value shoe_release_month']").verifyValue(pm.Parameter("Release Month"));
		results.endVerificationLogStep();
	}
	
	@Component(Name = "Verify Table Data on Shoe List Page", Params = {
			"RowToFind_Brand|*^*|Required!! Enter Brand Name. Ex: Valentino",
			"RowToFind_Name|*^*|Required!! Enter Shoe Name Amount. Valentino Camo Rockstud Pump",
			"RowToFind_Price|*^*|Required!! Enter the Price. Ex: $1,595.00",
			"RowToFind_Description|*^*|Optional!! Enter Description", 
			"RowToFind_Release Month|*^*|Required!! Enter the month. Ex: January", 
			"Row_Instance|*^*|Enter numeric value"
			})
	public void verifyTableDataonShoeListPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		ObjectTypes Page = Browser.Page("Shoe Store");
		results.startVerificationLogStep();
		Page.WebTable("Shoe Details Table").verifyRowInstancesInTable(pm);
		results.endVerificationLogStep();
		
	}
	
	@Component(Name = "Enter Data on Shoe List Page", Params = {
			"Shoe Brand|*^*|Valid Values: valid Shoe brand. Ex: Alegria",
			"Month|*^*|Valid Values: valid Shoe brand. Ex: January"
			})
	public void enterDataonShoeListPage(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		
		if (!(pm.Parameter("Shoe Brand")).equals("")){
			new WebObject("XPATH: (//a[contains(text(),'" + pm.Parameter("Shoe Brand")+ "')])[1]").actionClick();
		}
		if (!(pm.Parameter("Month")).equals("")){
			new WebObject("XPATH: (//a[contains(text(),'" + pm.Parameter("Month")+ "')])[1]").actionClick();
		}
	}
	
	@Component(Name = "Enter Data on Notify Me On Shoe Availablity", Params = {
			"Email Address|*^*|Valid Values: Email Address"
			})
	public void enterDataonNotifyMeOnShoeAvailablity(ParamManager pm) throws IOException, DatatypeConfigurationException, DDTFrameworkException {
		ObjectTypes Page = Browser.Page("Shoe Store");
		Page.WebTextBox("Notify Me Shoe Availability").set(pm.Parameter("Email Address"));
		Page.WebButton("Notify Me Submit").actionClick();
		
	}
	
	
}